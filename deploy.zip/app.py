﻿from flask import Flask
app = Flask(__name__)
@app.route('/')
def home():
    return '<h1>✅ Sales Dashboard</h1><p>Deployed successfully!</p>'
application = app
