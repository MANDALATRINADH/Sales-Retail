﻿from flask import Flask

app = Flask(__name__)

@app.route('/')
def home():
    return '<h1>✅ Sales Dashboard</h1><p>Deployed successfully via PowerShell!</p>'

@app.route('/health')
def health():
    return 'OK'

application = app

if __name__ == '__main__':
    app.run()
